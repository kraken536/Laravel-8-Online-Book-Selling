<!DOCTYPE html>
<html lang="en-GB">
<head>
			
		<meta charset="UTF-8"/>
		<link rel="profile" href="https://gmpg.org/xfn/11"/>
			
				<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=yes">
		<title>Page not found &#8211; ChapterOne</title>

<!-- Google Tag Manager for WordPress by gtm4wp.com -->
<script data-cfasync="false" data-pagespeed-no-defer type="text/javascript">//<![CDATA[
	var gtm4wp_datalayer_name = "dataLayer";
	var dataLayer = dataLayer || [];
//]]>
</script>
<!-- End Google Tag Manager for WordPress by gtm4wp.com --><link rel='dns-prefetch' href='//export.qodethemes.com' />
<link rel='dns-prefetch' href='//maps.googleapis.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="ChapterOne &raquo; Feed" href="https://chapterone.qodeinteractive.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="ChapterOne &raquo; Comments Feed" href="https://chapterone.qodeinteractive.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/chapterone.qodeinteractive.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.5.7"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://chapterone.qodeinteractive.com/wp-includes/css/dist/block-library/style.min.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='https://chapterone.qodeinteractive.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style.css?ver=2.3.0' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://chapterone.qodeinteractive.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.2.2' type='text/css' media='all' />
<link rel='stylesheet' id='rabbit_css-css'  href='https://export.qodethemes.com/_toolbar/assets/css/rbt-modules.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='https://chapterone.qodeinteractive.com/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.1.2' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='swiper-css'  href='https://chapterone.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/plugins/swiper/swiper.min.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='qi-addons-for-elementor-grid-style-css'  href='https://chapterone.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/css/grid.min.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='qi-addons-for-elementor-helper-parts-style-css'  href='https://chapterone.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/css/helper-parts.min.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='qi-addons-for-elementor-style-css'  href='https://chapterone.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/css/main.min.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='chapterone-mikado-default-style-css'  href='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/style.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='chapterone-mikado-modules-css'  href='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/css/modules.min.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='chapterone-mikado-dripicons-css'  href='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/framework/lib/icons-pack/dripicons/dripicons.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='chapterone-mikado-font_elegant-css'  href='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/framework/lib/icons-pack/elegant-icons/style.min.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='chapterone-mikado-font_awesome-css'  href='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/framework/lib/icons-pack/font-awesome/css/fontawesome-all.min.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='chapterone-mikado-ion_icons-css'  href='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/framework/lib/icons-pack/ion-icons/css/ionicons.min.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='chapterone-mikado-linea_icons-css'  href='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/framework/lib/icons-pack/linea-icons/style.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='chapterone-mikado-linear_icons-css'  href='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/framework/lib/icons-pack/linear-icons/style.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='chapterone-mikado-simple_line_icons-css'  href='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/framework/lib/icons-pack/simple-line-icons/simple-line-icons.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='mediaelement-css'  href='https://chapterone.qodeinteractive.com/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css?ver=4.2.13-9993131' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css'  href='https://chapterone.qodeinteractive.com/wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='chapterone-mikado-woo-css'  href='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/css/woocommerce.min.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='chapterone-mikado-woo-responsive-css'  href='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/css/woocommerce-responsive.min.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='chapterone-mikado-style-dynamic-css'  href='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/css/style_dynamic.css?ver=1580727382' type='text/css' media='all' />
<link rel='stylesheet' id='chapterone-mikado-modules-responsive-css'  href='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/css/modules-responsive.min.css?ver=5.5.7' type='text/css' media='all' />
<link rel='stylesheet' id='chapterone-mikado-style-dynamic-responsive-css'  href='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/css/style_dynamic_responsive.css?ver=1580727382' type='text/css' media='all' />
<link rel='stylesheet' id='chapterone-mikado-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Cormorant+Garamond%3A300%2C400%2C500%7CJosefin+Sans%3A300%2C400%2C500&#038;subset=latin-ext&#038;ver=1.0.0' type='text/css' media='all' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='vc_lte_ie9-css'  href='https://chapterone.qodeinteractive.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css?ver=6.0.5' type='text/css' media='screen' />
<![endif]-->
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp' id='jquery-core-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/plugins/revslider/public/assets/js/revolution.tools.min.js?ver=6.0' id='tp-tools-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.1.2' id='revmin-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70' id='jquery-blockui-js'></script>
<script type='text/javascript' id='wc-add-to-cart-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View basket","cart_url":"https:\/\/chapterone.qodeinteractive.com\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=3.7.2' id='wc-add-to-cart-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/plugins/duracelltomi-google-tag-manager/js/gtm4wp-form-move-tracker.js?ver=1.10.1' id='gtm4wp-form-move-tracker-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=6.0.5' id='vc_woocommerce-add-to-cart-js-js'></script>
<link rel="https://api.w.org/" href="https://chapterone.qodeinteractive.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://chapterone.qodeinteractive.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://chapterone.qodeinteractive.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.5.7" />
<meta name="generator" content="WooCommerce 3.7.2" />

<!-- Google Tag Manager for WordPress by gtm4wp.com -->
<script data-cfasync="false" data-pagespeed-no-defer type="text/javascript">//<![CDATA[
	var dataLayer_content = [];
	dataLayer.push( dataLayer_content );//]]>
</script>
<script data-cfasync="false">//<![CDATA[
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.'+'js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KTQ2BTD');//]]>
</script>
<!-- End Google Tag Manager -->
<!-- End Google Tag Manager for WordPress by gtm4wp.com -->	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<meta name="generator" content="Powered by Slider Revolution 6.1.2 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/09/cropped-favicon-512-32x32.png" sizes="32x32" />
<link rel="icon" href="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/09/cropped-favicon-512-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/09/cropped-favicon-512-180x180.png" />
<meta name="msapplication-TileImage" content="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/09/cropped-favicon-512-270x270.png" />
<script type="text/javascript">function setREVStartSize(t){try{var h,e=document.getElementById(t.c).parentNode.offsetWidth;if(e=0===e||isNaN(e)?window.innerWidth:e,t.tabw=void 0===t.tabw?0:parseInt(t.tabw),t.thumbw=void 0===t.thumbw?0:parseInt(t.thumbw),t.tabh=void 0===t.tabh?0:parseInt(t.tabh),t.thumbh=void 0===t.thumbh?0:parseInt(t.thumbh),t.tabhide=void 0===t.tabhide?0:parseInt(t.tabhide),t.thumbhide=void 0===t.thumbhide?0:parseInt(t.thumbhide),t.mh=void 0===t.mh||""==t.mh||"auto"===t.mh?0:parseInt(t.mh,0),"fullscreen"===t.layout||"fullscreen"===t.l)h=Math.max(t.mh,window.innerHeight);else{for(var i in t.gw=Array.isArray(t.gw)?t.gw:[t.gw],t.rl)void 0!==t.gw[i]&&0!==t.gw[i]||(t.gw[i]=t.gw[i-1]);for(var i in t.gh=void 0===t.el||""===t.el||Array.isArray(t.el)&&0==t.el.length?t.gh:t.el,t.gh=Array.isArray(t.gh)?t.gh:[t.gh],t.rl)void 0!==t.gh[i]&&0!==t.gh[i]||(t.gh[i]=t.gh[i-1]);var r,a=new Array(t.rl.length),n=0;for(var i in t.tabw=t.tabhide>=e?0:t.tabw,t.thumbw=t.thumbhide>=e?0:t.thumbw,t.tabh=t.tabhide>=e?0:t.tabh,t.thumbh=t.thumbhide>=e?0:t.thumbh,t.rl)a[i]=t.rl[i]<window.innerWidth?0:t.rl[i];for(var i in r=a[0],a)r>a[i]&&0<a[i]&&(r=a[i],n=i);var d=e>t.gw[n]+t.tabw+t.thumbw?1:(e-(t.tabw+t.thumbw))/t.gw[n];h=t.gh[n]*d+(t.tabh+t.thumbh)}void 0===window.rs_init_css&&(window.rs_init_css=document.head.appendChild(document.createElement("style"))),document.getElementById(t.c).height=h,window.rs_init_css.innerHTML+="#"+t.c+"_wrapper { height: "+h+"px }"}catch(t){console.log("Failure at Presize of Slider:"+t)}};</script>
		<style type="text/css" id="wp-custom-css">
			.mkdf-parallax-row-holder {
    background-size: cover;
}

@media only screen and (min-width: 1921px) {
	.mkdf-title-holder.mkdf-has-bg-image {
    	background-size: cover;
   }
}		</style>
		<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>
<body class="error404 theme-chapterone chapterone-core-1.0 woocommerce-no-js qodef-qi--no-touch qi-addons-for-elementor-1.2.2 chapterone-ver-1.0 mkdf-grid-1300 mkdf-wide-dropdown-menu-content-in-grid mkdf-sticky-header-on-scroll-up mkdf-dropdown-animate-height mkdf-header-standard mkdf-menu-area-shadow-disable mkdf-menu-area-in-grid-shadow-disable mkdf-menu-area-border-disable mkdf-menu-area-in-grid-border-disable mkdf-logo-area-border-disable mkdf-logo-area-in-grid-border-disable mkdf-header-vertical-shadow-disable mkdf-header-vertical-border-disable mkdf-side-menu-slide-from-right mkdf-woocommerce-columns-3 mkdf-woo-normal-space mkdf-woo-pl-info-below-image mkdf-woo-single-thumb-below-image mkdf-woo-single-has-pretty-photo mkdf-default-mobile-header mkdf-sticky-up-mobile-header mkdf-header-top-enabled mkdf-slide-from-header-bottom wpb-js-composer js-comp-ver-6.0.5 vc_responsive elementor-default elementor-kit-2601" itemscope itemtype="https://schema.org/WebPage">
<div class="mkdf-wrapper">
	<div class="mkdf-wrapper-inner">
			
		
	<div class="mkdf-top-bar">
				
					
			<div class="mkdf-vertical-align-containers">
				<div class="mkdf-position-left"><!--
				 -->
					<div class="mkdf-position-left-inner">
													<div id="text-4" class="widget widget_text mkdf-top-bar-widget">			<div class="textwidget"><p>FREE SHIPING FOR ORDERS OVER $50</p>
</div>
		</div>											</div>
				</div>
				<div class="mkdf-position-right"><!--
				 -->
					<div class="mkdf-position-right-inner">
													<div class="widget mkdf-social-icons-group-widget text-align-left">									<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover" data-hover-color="#d14031" style="color: #ffffff;;font-size: 14px;margin: 0 10px 0 0;"					   href="https://twitter.com/QodeInteractive" target="_blank">
						<span class="mkdf-social-icon-widget fab fa-twitter"></span>					</a>
													<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover" data-hover-color="#d14031" style="color: #ffffff;;font-size: 14px;margin: 0 10px 0 0;"					   href="https://www.instagram.com/qodeinteractive/" target="_blank">
						<span class="mkdf-social-icon-widget fab fa-instagram"></span>					</a>
													<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover" data-hover-color="#d14031" style="color: #ffffff;;font-size: 14px;margin: 0 10px 0 0;"					   href="https://www.facebook.com/QodeInteractive/" target="_blank">
						<span class="mkdf-social-icon-widget fab fa-facebook-f"></span>					</a>
													<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover" data-hover-color="#d14031" style="color: #ffffff;;font-size: 14px;margin: 0 10px 0 0;"					   href="https://dribbble.com/QodeInteractive" target="_blank">
						<span class="mkdf-social-icon-widget fab fa-dribbble"></span>					</a>
												</div>											</div>
				</div>
			</div>
			
					
		<div class="mkdf-slide-from-header-bottom-holder">
	<form action="https://chapterone.qodeinteractive.com/" method="get">
		<div class="mkdf-form-holder">
			<input type="text" placeholder="Search" name="s"
			       class="mkdf-search-field" autocomplete="off" required/>
			<button type="submit" class="mkdf-search-submit mkdf-search-submit-icon-pack">
				<span class="mkdf-search-label">GO</span>
			</button>
		</div>
	</form>
</div>	</div>
	
		
	<header class="mkdf-page-header">
				
					
			<div class="mkdf-menu-area mkdf-menu-left">
								
									
					<div class="mkdf-vertical-align-containers">
						<div class="mkdf-position-left"><!--
				 -->
							<div class="mkdf-position-left-inner">
								
	
	<div class="mkdf-logo-wrapper">
		<a itemprop="url"
		   href="https://chapterone.qodeinteractive.com/" style="height: 50px;">
			<img itemprop="image" class="mkdf-normal-logo"
			     src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/08/logo.png" width="124" height="100"  alt="logo"/>
			<img itemprop="image" class="mkdf-dark-logo"
			                                                  src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/08/logo.png" width="124" height="100"  alt="dark logo"/>			<img itemprop="image" class="mkdf-light-logo"
			                                                   src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/08/logo.png" width="124" height="100"  alt="light logo"/>		</a>
	</div>

																		
	<nav class="mkdf-main-menu mkdf-drop-down mkdf-default-nav">
		<ul id="menu-main-menu" class="clearfix"><li id="nav-menu-item-501" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Home</span><i class="mkdf-menu-arrow arrow_carrot-down"></i></span></a>
<div class="second"><div class="inner"><ul>
	<li id="nav-menu-item-500" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://chapterone.qodeinteractive.com/" class=""><span class="item_outer"><span class="item_text">Main Home</span></span></a></li>
	<li id="nav-menu-item-229" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/bestselling-author/" class=""><span class="item_outer"><span class="item_text">Bestselling Author</span></span></a></li>
	<li id="nav-menu-item-679" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/audiobook-home/" class=""><span class="item_outer"><span class="item_text">Audiobook Home</span></span></a></li>
	<li id="nav-menu-item-635" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/childrens-books/" class=""><span class="item_outer"><span class="item_text">Children’s Books</span></span></a></li>
	<li id="nav-menu-item-868" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/left-menu-home/" class=""><span class="item_outer"><span class="item_text">Left Menu Home</span></span></a></li>
	<li id="nav-menu-item-896" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/grid-home/" class=""><span class="item_outer"><span class="item_text">Grid Home</span></span></a></li>
	<li id="nav-menu-item-2018" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/landing/" class=""><span class="item_outer"><span class="item_text">Landing</span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-572" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Pages</span><i class="mkdf-menu-arrow arrow_carrot-down"></i></span></a>
<div class="second"><div class="inner"><ul>
	<li id="nav-menu-item-1008" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/about-me/" class=""><span class="item_outer"><span class="item_text">About Me</span></span></a></li>
	<li id="nav-menu-item-1120" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/about-us/" class=""><span class="item_outer"><span class="item_text">About Us</span></span></a></li>
	<li id="nav-menu-item-1119" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/our-events/" class=""><span class="item_outer"><span class="item_text">Our Events</span></span></a></li>
	<li id="nav-menu-item-889" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/our-premises/" class=""><span class="item_outer"><span class="item_text">Our Premises</span></span></a></li>
	<li id="nav-menu-item-886" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/coming-soon/" class=""><span class="item_outer"><span class="item_text">Coming Soon</span></span></a></li>
	<li id="nav-menu-item-1172" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/order-page/" class=""><span class="item_outer"><span class="item_text">Order Page</span></span></a></li>
	<li id="nav-menu-item-1009" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/contact-us/" class=""><span class="item_outer"><span class="item_text">Contact Us</span></span></a></li>
	<li id="nav-menu-item-888" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/pricing-options/" class=""><span class="item_outer"><span class="item_text">Pricing Options</span></span></a></li>
	<li id="nav-menu-item-887" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/faq-page/" class=""><span class="item_outer"><span class="item_text">FAQ Page</span></span></a></li>
	<li id="nav-menu-item-890" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://chapterone.qodeinteractive.com/404-error-page/" class=""><span class="item_outer"><span class="item_text">404 Error Page</span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-573" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Events</span><i class="mkdf-menu-arrow arrow_carrot-down"></i></span></a>
<div class="second"><div class="inner"><ul>
	<li id="nav-menu-item-1100" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/event-dates/" class=""><span class="item_outer"><span class="item_text">Event Dates</span></span></a></li>
	<li id="nav-menu-item-2163" class="menu-item menu-item-type-post_type menu-item-object-event "><a href="https://chapterone.qodeinteractive.com/event/festival-of-books/" class=""><span class="item_outer"><span class="item_text">Event Single</span></span></a></li>
</ul></div></div>
</li>
<li id="nav-menu-item-574" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Blog</span><i class="mkdf-menu-arrow arrow_carrot-down"></i></span></a>
<div class="second"><div class="inner"><ul>
	<li id="nav-menu-item-1083" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/right-sidebar/" class=""><span class="item_outer"><span class="item_text">Right Sidebar</span></span></a></li>
	<li id="nav-menu-item-1082" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/left-sidebar/" class=""><span class="item_outer"><span class="item_text">Left Sidebar</span></span></a></li>
	<li id="nav-menu-item-1086" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/no-sidebar/" class=""><span class="item_outer"><span class="item_text">No Sidebar</span></span></a></li>
	<li id="nav-menu-item-1034" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Blog Singles</span></span></a>
	<ul>
		<li id="nav-menu-item-1033" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/coffee-and-croissant-with-our-favorite-erika/" class=""><span class="item_outer"><span class="item_text">Standard</span></span></a></li>
		<li id="nav-menu-item-1035" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/how-to-spend-a-rainy-day-at-your-cozy-home/" class=""><span class="item_outer"><span class="item_text">No Sidebar</span></span></a></li>
		<li id="nav-menu-item-1054" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/connecting-readers-from-around-the-world/" class=""><span class="item_outer"><span class="item_text">Gallery</span></span></a></li>
		<li id="nav-menu-item-1074" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/jane-austen/" class=""><span class="item_outer"><span class="item_text">Quote</span></span></a></li>
		<li id="nav-menu-item-1077" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/taking-on-a-world-of-words/" class=""><span class="item_outer"><span class="item_text">Link</span></span></a></li>
		<li id="nav-menu-item-1059" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/books-for-kids/" class=""><span class="item_outer"><span class="item_text">Audio</span></span></a></li>
		<li id="nav-menu-item-1070" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/five-favorites-for-the-last-five-months/" class=""><span class="item_outer"><span class="item_text">Video</span></span></a></li>
	</ul>
</li>
</ul></div></div>
</li>
<li id="nav-menu-item-571" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Shop</span><i class="mkdf-menu-arrow arrow_carrot-down"></i></span></a>
<div class="second"><div class="inner"><ul>
	<li id="nav-menu-item-593" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/" class=""><span class="item_outer"><span class="item_text">Product List</span></span></a></li>
	<li id="nav-menu-item-585" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Product Singles</span></span></a>
	<ul>
		<li id="nav-menu-item-577" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/amsterdam-travel-stories/" class=""><span class="item_outer"><span class="item_text">Standard</span></span></a></li>
		<li id="nav-menu-item-578" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/easy-fast-healthy-recipes/" class=""><span class="item_outer"><span class="item_text">Grouped</span></span></a></li>
		<li id="nav-menu-item-584" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/winter-darkest-tragedy-3/" class=""><span class="item_outer"><span class="item_text">Variable</span></span></a></li>
		<li id="nav-menu-item-579" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/fantasy-storytelling-3/" class=""><span class="item_outer"><span class="item_text">Virtual</span></span></a></li>
		<li id="nav-menu-item-580" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/renaissance-history-3/" class=""><span class="item_outer"><span class="item_text">External</span></span></a></li>
		<li id="nav-menu-item-581" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/sea-sadness-pdf/" class=""><span class="item_outer"><span class="item_text">Downloadable</span></span></a></li>
		<li id="nav-menu-item-583" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/symphony-of-trilogy-2/" class=""><span class="item_outer"><span class="item_text">New</span></span></a></li>
		<li id="nav-menu-item-582" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/winter-darkest-tragedy-2/" class=""><span class="item_outer"><span class="item_text">On Sale</span></span></a></li>
		<li id="nav-menu-item-576" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/wellness-and-paradise-2/" class=""><span class="item_outer"><span class="item_text">Out of Stock</span></span></a></li>
	</ul>
</li>
	<li id="nav-menu-item-588" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Layouts</span></span></a>
	<ul>
		<li id="nav-menu-item-634" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/two-columns/" class=""><span class="item_outer"><span class="item_text">Two Columns</span></span></a></li>
		<li id="nav-menu-item-633" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/three-columns/" class=""><span class="item_outer"><span class="item_text">Three Columns</span></span></a></li>
		<li id="nav-menu-item-631" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/four-columns/" class=""><span class="item_outer"><span class="item_text">Four Columns</span></span></a></li>
		<li id="nav-menu-item-632" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/four-columns-wide/" class=""><span class="item_outer"><span class="item_text">Four Col. Wide</span></span></a></li>
		<li id="nav-menu-item-630" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/five-columns-wide/" class=""><span class="item_outer"><span class="item_text">Five Col. Wide</span></span></a></li>
		<li id="nav-menu-item-2123" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/six-columns-wide/" class=""><span class="item_outer"><span class="item_text">Six Col. Wide</span></span></a></li>
	</ul>
</li>
	<li id="nav-menu-item-589" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Pages</span></span></a>
	<ul>
		<li id="nav-menu-item-592" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/cart/" class=""><span class="item_outer"><span class="item_text">Cart</span></span></a></li>
		<li id="nav-menu-item-591" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/checkout/" class=""><span class="item_outer"><span class="item_text">Checkout</span></span></a></li>
		<li id="nav-menu-item-590" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/my-account/" class=""><span class="item_outer"><span class="item_text">My account</span></span></a></li>
	</ul>
</li>
</ul></div></div>
</li>
</ul>	</nav>

															</div>
						</div>
												<div class="mkdf-position-right"><!--
				 -->
							<div class="mkdf-position-right-inner">
																			<div class="mkdf-shopping-cart-holder mkdf-widget-border" >
				<div class="mkdf-shopping-cart-inner">
					<a itemprop="url" class="mkdf-header-cart mkdf-header-cart-icon-pack"   href="https://chapterone.qodeinteractive.com/cart/">
	<span class="mkdf-sc-opener-icon">
		<span aria-hidden="true" class="mkdf-icon-font-elegant icon_bag_alt "></span>		<span class="mkdf-sc-opener-count">5</span>
	</span>
	<span class="mkdf-sc-opener-total"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>334.00</span></span>
</a><div class="mkdf-sc-dropdown">
	<div class="mkdf-sc-dropdown-inner">
		<div class="mkdf-sc-dropdown-items">
				<div class="mkdf-sc-dropdown-item">
				<div class="mkdf-sc-dropdown-item-image">
					<a href="https://chapterone.qodeinteractive.com/product/renaissance-history/"><img width="600" height="829" src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/07/product-7-600x829.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="d" loading="lazy" /></a>				</div>
				<div class="mkdf-sc-dropdown-item-content">
					<h6 itemprop="name" class="mkdf-sc-dropdown-item-title entry-title">
						<a href="https://chapterone.qodeinteractive.com/product/renaissance-history/">Renaissance History</a>					</h6>
					<p class="mkdf-sc-dropdown-item-price">1 x <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>30.00</span></p>
					<a href="https://chapterone.qodeinteractive.com/cart/?remove_item=4b86abe48d358ecf194c56c69108433e&#038;_wpnonce=981293b090" class="mkdf-sc-dropdown-item-remove remove" title="Remove this item"><span aria-hidden="true" class="mkdf-icon-font-elegant icon_close " ></span></span></a>				</div>
			</div>
					<div class="mkdf-sc-dropdown-item">
				<div class="mkdf-sc-dropdown-item-image">
					<a href="https://chapterone.qodeinteractive.com/product/easy-fast-cooking/"><img width="600" height="829" src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/07/product-9-600x829.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="s" loading="lazy" /></a>				</div>
				<div class="mkdf-sc-dropdown-item-content">
					<h6 itemprop="name" class="mkdf-sc-dropdown-item-title entry-title">
						<a href="https://chapterone.qodeinteractive.com/product/easy-fast-cooking/">Easy Fast Cooking</a>					</h6>
					<p class="mkdf-sc-dropdown-item-price">1 x <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>78.00</span></p>
					<a href="https://chapterone.qodeinteractive.com/cart/?remove_item=fb2e203234df6dee15934e448ee88971&#038;_wpnonce=981293b090" class="mkdf-sc-dropdown-item-remove remove" title="Remove this item"><span aria-hidden="true" class="mkdf-icon-font-elegant icon_close " ></span></span></a>				</div>
			</div>
					<div class="mkdf-sc-dropdown-item">
				<div class="mkdf-sc-dropdown-item-image">
					<a href="https://chapterone.qodeinteractive.com/product/learn-to-love-yourself/"><img width="600" height="829" src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/07/product-6-600x829.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="s" loading="lazy" /></a>				</div>
				<div class="mkdf-sc-dropdown-item-content">
					<h6 itemprop="name" class="mkdf-sc-dropdown-item-title entry-title">
						<a href="https://chapterone.qodeinteractive.com/product/learn-to-love-yourself/">Learn To Love Yourself</a>					</h6>
					<p class="mkdf-sc-dropdown-item-price">1 x <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>50.00</span></p>
					<a href="https://chapterone.qodeinteractive.com/cart/?remove_item=b5f1e8fb36cd7fbeb7988e8639ac79e9&#038;_wpnonce=981293b090" class="mkdf-sc-dropdown-item-remove remove" title="Remove this item"><span aria-hidden="true" class="mkdf-icon-font-elegant icon_close " ></span></span></a>				</div>
			</div>
					<div class="mkdf-sc-dropdown-item">
				<div class="mkdf-sc-dropdown-item-image">
					<a href="https://chapterone.qodeinteractive.com/product/japan-travel-stories/"><img width="600" height="829" src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/07/product-10-600x829.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="s" loading="lazy" /></a>				</div>
				<div class="mkdf-sc-dropdown-item-content">
					<h6 itemprop="name" class="mkdf-sc-dropdown-item-title entry-title">
						<a href="https://chapterone.qodeinteractive.com/product/japan-travel-stories/">Japan Travel Stories</a>					</h6>
					<p class="mkdf-sc-dropdown-item-price">1 x <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>56.00</span></p>
					<a href="https://chapterone.qodeinteractive.com/cart/?remove_item=6f4920ea25403ec77bee9efce43ea25e&#038;_wpnonce=981293b090" class="mkdf-sc-dropdown-item-remove remove" title="Remove this item"><span aria-hidden="true" class="mkdf-icon-font-elegant icon_close " ></span></span></a>				</div>
			</div>
					<div class="mkdf-sc-dropdown-item">
				<div class="mkdf-sc-dropdown-item-image">
					<a href="https://chapterone.qodeinteractive.com/product/symphony-of-trilogy-2/"><img width="600" height="829" src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/07/product-2-600x829.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" loading="lazy" /></a>				</div>
				<div class="mkdf-sc-dropdown-item-content">
					<h6 itemprop="name" class="mkdf-sc-dropdown-item-title entry-title">
						<a href="https://chapterone.qodeinteractive.com/product/symphony-of-trilogy-2/">Symphony Of Trilogy</a>					</h6>
					<p class="mkdf-sc-dropdown-item-price">1 x <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>120.00</span></p>
					<a href="https://chapterone.qodeinteractive.com/cart/?remove_item=335f5352088d7d9bf74191e006d8e24c&#038;_wpnonce=981293b090" class="mkdf-sc-dropdown-item-remove remove" title="Remove this item"><span aria-hidden="true" class="mkdf-icon-font-elegant icon_close " ></span></span></a>				</div>
			</div>
		</div><div class="mkdf-sc-dropdown-subtotal">
	<h6 class="mkdf-sc-dropdown-total">Total:</h6>
	<span class="mkdf-sc-dropdown-total-amount"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>334.00</span></span>
</div><div class="mkdf-sc-dropdown-button-holder">
	<a itemprop="url" href="https://chapterone.qodeinteractive.com/cart/"
	   class="mkdf-sc-dropdown-button-cart">View Cart</a>
	<a itemprop="url" href="https://chapterone.qodeinteractive.com/checkout/"
	   class="mkdf-sc-dropdown-button-checkout">View Checkout</a>
</div>	</div>
</div>				</div>
			</div>
						
			<a   class="mkdf-search-opener mkdf-icon-has-hover mkdf-widget-border mkdf-search-opener-icon-pack"					href="javascript:void(0)">
	            <span class="mkdf-search-opener-wrapper">
		            <span aria-hidden="true" class="mkdf-icon-font-elegant icon_search " ></span>		            	            </span>
			</a>
					<a class="mkdf-side-menu-button-opener mkdf-icon-has-hover mkdf-widget-border mkdf-side-menu-button-opener-icon-pack" 					href="javascript:void(0)" >
								<span class="mkdf-side-menu-icon">
					<span aria-hidden="true" class="mkdf-icon-font-elegant icon_menu "></span>	            </span>
			</a>
									</div>
						</div>
					</div>
					
								</div>
			
					
			
	<div class="mkdf-sticky-header">
				<div class="mkdf-sticky-holder mkdf-menu-left">
							<div class="mkdf-vertical-align-containers">
					<div class="mkdf-position-left"><!--
                 -->
						<div class="mkdf-position-left-inner">
							
	
	<div class="mkdf-logo-wrapper">
		<a itemprop="url"
		   href="https://chapterone.qodeinteractive.com/" style="height: 50px;">
			<img itemprop="image" class="mkdf-normal-logo"
			     src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/08/logo.png" width="124" height="100"  alt="logo"/>
			<img itemprop="image" class="mkdf-dark-logo"
			                                                  src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/08/logo.png" width="124" height="100"  alt="dark logo"/>			<img itemprop="image" class="mkdf-light-logo"
			                                                   src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/08/logo.png" width="124" height="100"  alt="light logo"/>		</a>
	</div>

																
	<nav class="mkdf-main-menu mkdf-drop-down mkdf-sticky-nav">
		<ul id="menu-main-menu-1" class="clearfix"><li id="sticky-nav-menu-item-501" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Home</span><span class="plus"></span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
	<li id="sticky-nav-menu-item-500" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://chapterone.qodeinteractive.com/" class=""><span class="item_outer"><span class="item_text">Main Home</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-229" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/bestselling-author/" class=""><span class="item_outer"><span class="item_text">Bestselling Author</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-679" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/audiobook-home/" class=""><span class="item_outer"><span class="item_text">Audiobook Home</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-635" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/childrens-books/" class=""><span class="item_outer"><span class="item_text">Children’s Books</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-868" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/left-menu-home/" class=""><span class="item_outer"><span class="item_text">Left Menu Home</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-896" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/grid-home/" class=""><span class="item_outer"><span class="item_text">Grid Home</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-2018" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/landing/" class=""><span class="item_outer"><span class="item_text">Landing</span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-572" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Pages</span><span class="plus"></span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
	<li id="sticky-nav-menu-item-1008" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/about-me/" class=""><span class="item_outer"><span class="item_text">About Me</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-1120" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/about-us/" class=""><span class="item_outer"><span class="item_text">About Us</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-1119" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/our-events/" class=""><span class="item_outer"><span class="item_text">Our Events</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-889" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/our-premises/" class=""><span class="item_outer"><span class="item_text">Our Premises</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-886" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/coming-soon/" class=""><span class="item_outer"><span class="item_text">Coming Soon</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-1172" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/order-page/" class=""><span class="item_outer"><span class="item_text">Order Page</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-1009" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/contact-us/" class=""><span class="item_outer"><span class="item_text">Contact Us</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-888" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/pricing-options/" class=""><span class="item_outer"><span class="item_text">Pricing Options</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-887" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/faq-page/" class=""><span class="item_outer"><span class="item_text">FAQ Page</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-890" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://chapterone.qodeinteractive.com/404-error-page/" class=""><span class="item_outer"><span class="item_text">404 Error Page</span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-573" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Events</span><span class="plus"></span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
	<li id="sticky-nav-menu-item-1100" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/event-dates/" class=""><span class="item_outer"><span class="item_text">Event Dates</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-2163" class="menu-item menu-item-type-post_type menu-item-object-event "><a href="https://chapterone.qodeinteractive.com/event/festival-of-books/" class=""><span class="item_outer"><span class="item_text">Event Single</span><span class="plus"></span></span></a></li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-574" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Blog</span><span class="plus"></span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
	<li id="sticky-nav-menu-item-1083" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/right-sidebar/" class=""><span class="item_outer"><span class="item_text">Right Sidebar</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-1082" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/left-sidebar/" class=""><span class="item_outer"><span class="item_text">Left Sidebar</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-1086" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/no-sidebar/" class=""><span class="item_outer"><span class="item_text">No Sidebar</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-1034" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=" no_link" onclick="JavaScript: return false;"><span class="item_outer"><span class="item_text">Blog Singles</span><span class="plus"></span></span></a>
	<ul>
		<li id="sticky-nav-menu-item-1033" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/coffee-and-croissant-with-our-favorite-erika/" class=""><span class="item_outer"><span class="item_text">Standard</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-1035" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/how-to-spend-a-rainy-day-at-your-cozy-home/" class=""><span class="item_outer"><span class="item_text">No Sidebar</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-1054" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/connecting-readers-from-around-the-world/" class=""><span class="item_outer"><span class="item_text">Gallery</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-1074" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/jane-austen/" class=""><span class="item_outer"><span class="item_text">Quote</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-1077" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/taking-on-a-world-of-words/" class=""><span class="item_outer"><span class="item_text">Link</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-1059" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/books-for-kids/" class=""><span class="item_outer"><span class="item_text">Audio</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-1070" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/five-favorites-for-the-last-five-months/" class=""><span class="item_outer"><span class="item_text">Video</span><span class="plus"></span></span></a></li>
	</ul>
</li>
</ul></div></div>
</li>
<li id="sticky-nav-menu-item-571" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub narrow"><a href="#" class=""><span class="item_outer"><span class="item_text">Shop</span><span class="plus"></span><i class="mkdf-menu-arrow fa fa-angle-down"></i></span></a>
<div class="second"><div class="inner"><ul>
	<li id="sticky-nav-menu-item-593" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/" class=""><span class="item_outer"><span class="item_text">Product List</span><span class="plus"></span></span></a></li>
	<li id="sticky-nav-menu-item-585" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Product Singles</span><span class="plus"></span></span></a>
	<ul>
		<li id="sticky-nav-menu-item-577" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/amsterdam-travel-stories/" class=""><span class="item_outer"><span class="item_text">Standard</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-578" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/easy-fast-healthy-recipes/" class=""><span class="item_outer"><span class="item_text">Grouped</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-584" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/winter-darkest-tragedy-3/" class=""><span class="item_outer"><span class="item_text">Variable</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-579" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/fantasy-storytelling-3/" class=""><span class="item_outer"><span class="item_text">Virtual</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-580" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/renaissance-history-3/" class=""><span class="item_outer"><span class="item_text">External</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-581" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/sea-sadness-pdf/" class=""><span class="item_outer"><span class="item_text">Downloadable</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-583" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/symphony-of-trilogy-2/" class=""><span class="item_outer"><span class="item_text">New</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-582" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/winter-darkest-tragedy-2/" class=""><span class="item_outer"><span class="item_text">On Sale</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-576" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/wellness-and-paradise-2/" class=""><span class="item_outer"><span class="item_text">Out of Stock</span><span class="plus"></span></span></a></li>
	</ul>
</li>
	<li id="sticky-nav-menu-item-588" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Layouts</span><span class="plus"></span></span></a>
	<ul>
		<li id="sticky-nav-menu-item-634" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/two-columns/" class=""><span class="item_outer"><span class="item_text">Two Columns</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-633" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/three-columns/" class=""><span class="item_outer"><span class="item_text">Three Columns</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-631" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/four-columns/" class=""><span class="item_outer"><span class="item_text">Four Columns</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-632" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/four-columns-wide/" class=""><span class="item_outer"><span class="item_text">Four Col. Wide</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-630" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/five-columns-wide/" class=""><span class="item_outer"><span class="item_text">Five Col. Wide</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-2123" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/six-columns-wide/" class=""><span class="item_outer"><span class="item_text">Six Col. Wide</span><span class="plus"></span></span></a></li>
	</ul>
</li>
	<li id="sticky-nav-menu-item-589" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children sub"><a href="#" class=""><span class="item_outer"><span class="item_text">Pages</span><span class="plus"></span></span></a>
	<ul>
		<li id="sticky-nav-menu-item-592" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/cart/" class=""><span class="item_outer"><span class="item_text">Cart</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-591" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/checkout/" class=""><span class="item_outer"><span class="item_text">Checkout</span><span class="plus"></span></span></a></li>
		<li id="sticky-nav-menu-item-590" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/my-account/" class=""><span class="item_outer"><span class="item_text">My account</span><span class="plus"></span></span></a></li>
	</ul>
</li>
</ul></div></div>
</li>
</ul>	</nav>

													</div>
					</div>
										<div class="mkdf-position-right"><!--
                 -->
						<div class="mkdf-position-right-inner">
																	
			<a   class="mkdf-search-opener mkdf-icon-has-hover mkdf-widget-border mkdf-search-opener-icon-pack"					href="javascript:void(0)">
	            <span class="mkdf-search-opener-wrapper">
		            <span aria-hidden="true" class="mkdf-icon-font-elegant icon_search " ></span>		            	            </span>
			</a>
					<a class="mkdf-side-menu-button-opener mkdf-icon-has-hover mkdf-widget-border mkdf-side-menu-button-opener-icon-pack" 					href="javascript:void(0)" >
								<span class="mkdf-side-menu-icon">
					<span aria-hidden="true" class="mkdf-icon-font-elegant icon_menu "></span>	            </span>
			</a>
								</div>
					</div>
				</div>
						</div>
			</div>

		
		<div class="mkdf-slide-from-header-bottom-holder">
	<form action="https://chapterone.qodeinteractive.com/" method="get">
		<div class="mkdf-form-holder">
			<input type="text" placeholder="Search" name="s"
			       class="mkdf-search-field" autocomplete="off" required/>
			<button type="submit" class="mkdf-search-submit mkdf-search-submit-icon-pack">
				<span class="mkdf-search-label">GO</span>
			</button>
		</div>
	</form>
</div>	</header>

	
	<header class="mkdf-mobile-header">
				
		<div class="mkdf-mobile-header-inner">
			<div class="mkdf-mobile-header-holder">
								<div class="mkdf-grid">
										<div class="mkdf-vertical-align-containers">
						<div class="mkdf-position-left"><!--
                     -->
							<div class="mkdf-position-left-inner">
									
	<div class="mkdf-mobile-logo-wrapper">
		<a itemprop="url"
		   href="https://chapterone.qodeinteractive.com/" style="height: 50px">
			<img itemprop="image"
			     src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/08/logo.png" width="124" height="100"  alt="Mobile Logo"/>
		</a>
	</div>

							</div>
						</div>
						<div class="mkdf-position-right"><!--
                     -->
							<div class="mkdf-position-right-inner">
											<div class="mkdf-shopping-cart-holder mkdf-widget-border" >
				<div class="mkdf-shopping-cart-inner">
					<a itemprop="url" class="mkdf-header-cart mkdf-header-cart-icon-pack"   href="https://chapterone.qodeinteractive.com/cart/">
	<span class="mkdf-sc-opener-icon">
		<span aria-hidden="true" class="mkdf-icon-font-elegant icon_bag_alt "></span>		<span class="mkdf-sc-opener-count">5</span>
	</span>
	<span class="mkdf-sc-opener-total"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>334.00</span></span>
</a><div class="mkdf-sc-dropdown">
	<div class="mkdf-sc-dropdown-inner">
		<div class="mkdf-sc-dropdown-items">
				<div class="mkdf-sc-dropdown-item">
				<div class="mkdf-sc-dropdown-item-image">
					<a href="https://chapterone.qodeinteractive.com/product/renaissance-history/"><img width="600" height="829" src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/07/product-7-600x829.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="d" loading="lazy" /></a>				</div>
				<div class="mkdf-sc-dropdown-item-content">
					<h6 itemprop="name" class="mkdf-sc-dropdown-item-title entry-title">
						<a href="https://chapterone.qodeinteractive.com/product/renaissance-history/">Renaissance History</a>					</h6>
					<p class="mkdf-sc-dropdown-item-price">1 x <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>30.00</span></p>
					<a href="https://chapterone.qodeinteractive.com/cart/?remove_item=4b86abe48d358ecf194c56c69108433e&#038;_wpnonce=981293b090" class="mkdf-sc-dropdown-item-remove remove" title="Remove this item"><span aria-hidden="true" class="mkdf-icon-font-elegant icon_close " ></span></span></a>				</div>
			</div>
					<div class="mkdf-sc-dropdown-item">
				<div class="mkdf-sc-dropdown-item-image">
					<a href="https://chapterone.qodeinteractive.com/product/easy-fast-cooking/"><img width="600" height="829" src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/07/product-9-600x829.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="s" loading="lazy" /></a>				</div>
				<div class="mkdf-sc-dropdown-item-content">
					<h6 itemprop="name" class="mkdf-sc-dropdown-item-title entry-title">
						<a href="https://chapterone.qodeinteractive.com/product/easy-fast-cooking/">Easy Fast Cooking</a>					</h6>
					<p class="mkdf-sc-dropdown-item-price">1 x <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>78.00</span></p>
					<a href="https://chapterone.qodeinteractive.com/cart/?remove_item=fb2e203234df6dee15934e448ee88971&#038;_wpnonce=981293b090" class="mkdf-sc-dropdown-item-remove remove" title="Remove this item"><span aria-hidden="true" class="mkdf-icon-font-elegant icon_close " ></span></span></a>				</div>
			</div>
					<div class="mkdf-sc-dropdown-item">
				<div class="mkdf-sc-dropdown-item-image">
					<a href="https://chapterone.qodeinteractive.com/product/learn-to-love-yourself/"><img width="600" height="829" src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/07/product-6-600x829.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="s" loading="lazy" /></a>				</div>
				<div class="mkdf-sc-dropdown-item-content">
					<h6 itemprop="name" class="mkdf-sc-dropdown-item-title entry-title">
						<a href="https://chapterone.qodeinteractive.com/product/learn-to-love-yourself/">Learn To Love Yourself</a>					</h6>
					<p class="mkdf-sc-dropdown-item-price">1 x <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>50.00</span></p>
					<a href="https://chapterone.qodeinteractive.com/cart/?remove_item=b5f1e8fb36cd7fbeb7988e8639ac79e9&#038;_wpnonce=981293b090" class="mkdf-sc-dropdown-item-remove remove" title="Remove this item"><span aria-hidden="true" class="mkdf-icon-font-elegant icon_close " ></span></span></a>				</div>
			</div>
					<div class="mkdf-sc-dropdown-item">
				<div class="mkdf-sc-dropdown-item-image">
					<a href="https://chapterone.qodeinteractive.com/product/japan-travel-stories/"><img width="600" height="829" src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/07/product-10-600x829.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="s" loading="lazy" /></a>				</div>
				<div class="mkdf-sc-dropdown-item-content">
					<h6 itemprop="name" class="mkdf-sc-dropdown-item-title entry-title">
						<a href="https://chapterone.qodeinteractive.com/product/japan-travel-stories/">Japan Travel Stories</a>					</h6>
					<p class="mkdf-sc-dropdown-item-price">1 x <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>56.00</span></p>
					<a href="https://chapterone.qodeinteractive.com/cart/?remove_item=6f4920ea25403ec77bee9efce43ea25e&#038;_wpnonce=981293b090" class="mkdf-sc-dropdown-item-remove remove" title="Remove this item"><span aria-hidden="true" class="mkdf-icon-font-elegant icon_close " ></span></span></a>				</div>
			</div>
					<div class="mkdf-sc-dropdown-item">
				<div class="mkdf-sc-dropdown-item-image">
					<a href="https://chapterone.qodeinteractive.com/product/symphony-of-trilogy-2/"><img width="600" height="829" src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/07/product-2-600x829.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="a" loading="lazy" /></a>				</div>
				<div class="mkdf-sc-dropdown-item-content">
					<h6 itemprop="name" class="mkdf-sc-dropdown-item-title entry-title">
						<a href="https://chapterone.qodeinteractive.com/product/symphony-of-trilogy-2/">Symphony Of Trilogy</a>					</h6>
					<p class="mkdf-sc-dropdown-item-price">1 x <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>120.00</span></p>
					<a href="https://chapterone.qodeinteractive.com/cart/?remove_item=335f5352088d7d9bf74191e006d8e24c&#038;_wpnonce=981293b090" class="mkdf-sc-dropdown-item-remove remove" title="Remove this item"><span aria-hidden="true" class="mkdf-icon-font-elegant icon_close " ></span></span></a>				</div>
			</div>
		</div><div class="mkdf-sc-dropdown-subtotal">
	<h6 class="mkdf-sc-dropdown-total">Total:</h6>
	<span class="mkdf-sc-dropdown-total-amount"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>334.00</span></span>
</div><div class="mkdf-sc-dropdown-button-holder">
	<a itemprop="url" href="https://chapterone.qodeinteractive.com/cart/"
	   class="mkdf-sc-dropdown-button-cart">View Cart</a>
	<a itemprop="url" href="https://chapterone.qodeinteractive.com/checkout/"
	   class="mkdf-sc-dropdown-button-checkout">View Checkout</a>
</div>	</div>
</div>				</div>
			</div>
																				<div class="mkdf-mobile-menu-opener mkdf-mobile-menu-opener-icon-pack">
										<a href="javascript:void(0)">
																						<span class="mkdf-mobile-menu-icon">
                                            <span aria-hidden="true" class="mkdf-icon-font-elegant icon_menu "></span>                                        </span>
										</a>
									</div>
															</div>
						</div>
					</div>
									</div>
						</div>
			
	<nav class="mkdf-mobile-nav" role="navigation" aria-label="Mobile Menu">
		<div class="mkdf-grid">
			<ul id="menu-main-menu-2" class=""><li id="mobile-menu-item-501" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Home</span></h6><span class="mobile_arrow"><i class="mkdf-sub-arrow mkdf-icon-font-elegant arrow_carrot-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
	<li id="mobile-menu-item-500" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home "><a href="https://chapterone.qodeinteractive.com/" class=""><span>Main Home</span></a></li>
	<li id="mobile-menu-item-229" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/bestselling-author/" class=""><span>Bestselling Author</span></a></li>
	<li id="mobile-menu-item-679" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/audiobook-home/" class=""><span>Audiobook Home</span></a></li>
	<li id="mobile-menu-item-635" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/childrens-books/" class=""><span>Children’s Books</span></a></li>
	<li id="mobile-menu-item-868" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/left-menu-home/" class=""><span>Left Menu Home</span></a></li>
	<li id="mobile-menu-item-896" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/grid-home/" class=""><span>Grid Home</span></a></li>
	<li id="mobile-menu-item-2018" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/landing/" class=""><span>Landing</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-572" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" mkdf-mobile-no-link"><span>Pages</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow mkdf-icon-font-elegant arrow_carrot-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
	<li id="mobile-menu-item-1008" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/about-me/" class=""><span>About Me</span></a></li>
	<li id="mobile-menu-item-1120" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/about-us/" class=""><span>About Us</span></a></li>
	<li id="mobile-menu-item-1119" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/our-events/" class=""><span>Our Events</span></a></li>
	<li id="mobile-menu-item-889" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/our-premises/" class=""><span>Our Premises</span></a></li>
	<li id="mobile-menu-item-886" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/coming-soon/" class=""><span>Coming Soon</span></a></li>
	<li id="mobile-menu-item-1172" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/order-page/" class=""><span>Order Page</span></a></li>
	<li id="mobile-menu-item-1009" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/contact-us/" class=""><span>Contact Us</span></a></li>
	<li id="mobile-menu-item-888" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/pricing-options/" class=""><span>Pricing Options</span></a></li>
	<li id="mobile-menu-item-887" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/faq-page/" class=""><span>FAQ Page</span></a></li>
	<li id="mobile-menu-item-890" class="menu-item menu-item-type-custom menu-item-object-custom "><a href="https://chapterone.qodeinteractive.com/404-error-page/" class=""><span>404 Error Page</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-573" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" mkdf-mobile-no-link"><span>Events</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow mkdf-icon-font-elegant arrow_carrot-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
	<li id="mobile-menu-item-1100" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/event-dates/" class=""><span>Event Dates</span></a></li>
	<li id="mobile-menu-item-2163" class="menu-item menu-item-type-post_type menu-item-object-event "><a href="https://chapterone.qodeinteractive.com/event/festival-of-books/" class=""><span>Event Single</span></a></li>
</ul>
</li>
<li id="mobile-menu-item-574" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" mkdf-mobile-no-link"><span>Blog</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow mkdf-icon-font-elegant arrow_carrot-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
	<li id="mobile-menu-item-1083" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/right-sidebar/" class=""><span>Right Sidebar</span></a></li>
	<li id="mobile-menu-item-1082" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/left-sidebar/" class=""><span>Left Sidebar</span></a></li>
	<li id="mobile-menu-item-1086" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/no-sidebar/" class=""><span>No Sidebar</span></a></li>
	<li id="mobile-menu-item-1034" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><h6><span>Blog Singles</span></h6><span class="mobile_arrow"><i class="mkdf-sub-arrow mkdf-icon-font-elegant arrow_carrot-right"></i><i class="fa fa-angle-down"></i></span>
	<ul class="sub_menu">
		<li id="mobile-menu-item-1033" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/coffee-and-croissant-with-our-favorite-erika/" class=""><span>Standard</span></a></li>
		<li id="mobile-menu-item-1035" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/how-to-spend-a-rainy-day-at-your-cozy-home/" class=""><span>No Sidebar</span></a></li>
		<li id="mobile-menu-item-1054" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/connecting-readers-from-around-the-world/" class=""><span>Gallery</span></a></li>
		<li id="mobile-menu-item-1074" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/jane-austen/" class=""><span>Quote</span></a></li>
		<li id="mobile-menu-item-1077" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/taking-on-a-world-of-words/" class=""><span>Link</span></a></li>
		<li id="mobile-menu-item-1059" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/books-for-kids/" class=""><span>Audio</span></a></li>
		<li id="mobile-menu-item-1070" class="menu-item menu-item-type-post_type menu-item-object-post "><a href="https://chapterone.qodeinteractive.com/five-favorites-for-the-last-five-months/" class=""><span>Video</span></a></li>
	</ul>
</li>
</ul>
</li>
<li id="mobile-menu-item-571" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" mkdf-mobile-no-link"><span>Shop</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow mkdf-icon-font-elegant arrow_carrot-right"></i><i class="fa fa-angle-down"></i></span>
<ul class="sub_menu">
	<li id="mobile-menu-item-593" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/" class=""><span>Product List</span></a></li>
	<li id="mobile-menu-item-585" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" mkdf-mobile-no-link"><span>Product Singles</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow mkdf-icon-font-elegant arrow_carrot-right"></i><i class="fa fa-angle-down"></i></span>
	<ul class="sub_menu">
		<li id="mobile-menu-item-577" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/amsterdam-travel-stories/" class=""><span>Standard</span></a></li>
		<li id="mobile-menu-item-578" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/easy-fast-healthy-recipes/" class=""><span>Grouped</span></a></li>
		<li id="mobile-menu-item-584" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/winter-darkest-tragedy-3/" class=""><span>Variable</span></a></li>
		<li id="mobile-menu-item-579" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/fantasy-storytelling-3/" class=""><span>Virtual</span></a></li>
		<li id="mobile-menu-item-580" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/renaissance-history-3/" class=""><span>External</span></a></li>
		<li id="mobile-menu-item-581" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/sea-sadness-pdf/" class=""><span>Downloadable</span></a></li>
		<li id="mobile-menu-item-583" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/symphony-of-trilogy-2/" class=""><span>New</span></a></li>
		<li id="mobile-menu-item-582" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/winter-darkest-tragedy-2/" class=""><span>On Sale</span></a></li>
		<li id="mobile-menu-item-576" class="menu-item menu-item-type-post_type menu-item-object-product "><a href="https://chapterone.qodeinteractive.com/product/wellness-and-paradise-2/" class=""><span>Out of Stock</span></a></li>
	</ul>
</li>
	<li id="mobile-menu-item-588" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" mkdf-mobile-no-link"><span>Layouts</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow mkdf-icon-font-elegant arrow_carrot-right"></i><i class="fa fa-angle-down"></i></span>
	<ul class="sub_menu">
		<li id="mobile-menu-item-634" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/two-columns/" class=""><span>Two Columns</span></a></li>
		<li id="mobile-menu-item-633" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/three-columns/" class=""><span>Three Columns</span></a></li>
		<li id="mobile-menu-item-631" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/four-columns/" class=""><span>Four Columns</span></a></li>
		<li id="mobile-menu-item-632" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/four-columns-wide/" class=""><span>Four Col. Wide</span></a></li>
		<li id="mobile-menu-item-630" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/five-columns-wide/" class=""><span>Five Col. Wide</span></a></li>
		<li id="mobile-menu-item-2123" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/shop-list/six-columns-wide/" class=""><span>Six Col. Wide</span></a></li>
	</ul>
</li>
	<li id="mobile-menu-item-589" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children  has_sub"><a href="#" class=" mkdf-mobile-no-link"><span>Pages</span></a><span class="mobile_arrow"><i class="mkdf-sub-arrow mkdf-icon-font-elegant arrow_carrot-right"></i><i class="fa fa-angle-down"></i></span>
	<ul class="sub_menu">
		<li id="mobile-menu-item-592" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/cart/" class=""><span>Cart</span></a></li>
		<li id="mobile-menu-item-591" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/checkout/" class=""><span>Checkout</span></a></li>
		<li id="mobile-menu-item-590" class="menu-item menu-item-type-post_type menu-item-object-page "><a href="https://chapterone.qodeinteractive.com/my-account/" class=""><span>My account</span></a></li>
	</ul>
</li>
</ul>
</li>
</ul>		</div>
	</nav>

		</div>
		
		<div class="mkdf-slide-from-header-bottom-holder">
	<form action="https://chapterone.qodeinteractive.com/" method="get">
		<div class="mkdf-form-holder">
			<input type="text" placeholder="Search" name="s"
			       class="mkdf-search-field" autocomplete="off" required/>
			<button type="submit" class="mkdf-search-submit mkdf-search-submit-icon-pack">
				<span class="mkdf-search-label">GO</span>
			</button>
		</div>
	</form>
</div>	</header>

			<a id='mkdf-back-to-top' href='#'>
                <span class="mkdf-icon-stack">
                     <i class="mkdf-icon-font-awesome fa fa-angle-up "></i>                </span>
			</a>
				
		<div class="mkdf-content" style="margin-top: -100px">
			<div class="mkdf-content-inner">
<div class="mkdf-page-not-found">
		
	<h1 class="mkdf-404-title">
		404	</h1>
	
	<h3 class="mkdf-404-subtitle">
		Page not found	</h3>
	
	<p class="mkdf-404-text">
		Oops! The page you are looking for does not exist. It might have been moved or deleted.	</p>
	
	<a itemprop="url" href="https://chapterone.qodeinteractive.com/"   target="_self"  class="mkdf-btn mkdf-btn-medium mkdf-btn-outline"  >	<span class="mkdf-btn-text">Go to home</span>	</a></div>
</div>
</div>
</div>
</div>
<div class="rbt-toolbar" data-theme="ChapterOne" data-featured="" data-button-position="70%" data-button-horizontal="right" data-button-alt="no" ></div>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KTQ2BTD"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
			<script type="text/javascript">
			var wc_product_block_data = JSON.parse( decodeURIComponent( '%7B%22min_columns%22%3A1%2C%22max_columns%22%3A6%2C%22default_columns%22%3A3%2C%22min_rows%22%3A1%2C%22max_rows%22%3A6%2C%22default_rows%22%3A1%2C%22thumbnail_size%22%3A300%2C%22placeholderImgSrc%22%3A%22https%3A%5C%2F%5C%2Fchapterone.qodeinteractive.com%5C%2Fwp-content%5C%2Fuploads%5C%2Fwoocommerce-placeholder-600x600.png%22%2C%22min_height%22%3A500%2C%22default_height%22%3A500%2C%22isLargeCatalog%22%3Afalse%2C%22limitTags%22%3Afalse%2C%22hasTags%22%3Atrue%2C%22productCategories%22%3A%5B%7B%22term_id%22%3A15%2C%22name%22%3A%22New%22%2C%22slug%22%3A%22new%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A15%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A12%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fchapterone.qodeinteractive.com%5C%2Fproduct-category%5C%2Fnew%5C%2F%22%7D%2C%7B%22term_id%22%3A20%2C%22name%22%3A%22Action%22%2C%22slug%22%3A%22action%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A20%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A13%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fchapterone.qodeinteractive.com%5C%2Fproduct-category%5C%2Faction%5C%2F%22%7D%2C%7B%22term_id%22%3A57%2C%22name%22%3A%22Art%22%2C%22slug%22%3A%22art%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A57%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A54%2C%22count%22%3A3%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fchapterone.qodeinteractive.com%5C%2Fproduct-category%5C%2Fbest-sellers%5C%2Fart%5C%2F%22%7D%2C%7B%22term_id%22%3A54%2C%22name%22%3A%22Best%20Sellers%22%2C%22slug%22%3A%22best-sellers%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A54%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A12%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fchapterone.qodeinteractive.com%5C%2Fproduct-category%5C%2Fbest-sellers%5C%2F%22%7D%2C%7B%22term_id%22%3A42%2C%22name%22%3A%22Design%22%2C%22slug%22%3A%22design%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A42%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A6%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fchapterone.qodeinteractive.com%5C%2Fproduct-category%5C%2Fdesign%5C%2F%22%7D%2C%7B%22term_id%22%3A55%2C%22name%22%3A%22Fantasy%22%2C%22slug%22%3A%22fantasy%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A55%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A54%2C%22count%22%3A2%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fchapterone.qodeinteractive.com%5C%2Fproduct-category%5C%2Fbest-sellers%5C%2Ffantasy%5C%2F%22%7D%2C%7B%22term_id%22%3A56%2C%22name%22%3A%22History%22%2C%22slug%22%3A%22history%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A56%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A54%2C%22count%22%3A3%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fchapterone.qodeinteractive.com%5C%2Fproduct-category%5C%2Fbest-sellers%5C%2Fhistory%5C%2F%22%7D%2C%7B%22term_id%22%3A24%2C%22name%22%3A%22Home%22%2C%22slug%22%3A%22home%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A24%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A10%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fchapterone.qodeinteractive.com%5C%2Fproduct-category%5C%2Fhome%5C%2F%22%7D%2C%7B%22term_id%22%3A58%2C%22name%22%3A%22Love%20Stories%22%2C%22slug%22%3A%22love-stories%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A58%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A54%2C%22count%22%3A2%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fchapterone.qodeinteractive.com%5C%2Fproduct-category%5C%2Fbest-sellers%5C%2Flove-stories%5C%2F%22%7D%5D%2C%22homeUrl%22%3A%22https%3A%5C%2F%5C%2Fchapterone.qodeinteractive.com%5C%2F%22%7D' ) );
		</script>
		<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/chapterone.qodeinteractive.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.2.2' id='contact-form-7-js'></script>
<script type='text/javascript' src='https://export.qodethemes.com/_toolbar/assets/js/rbt-modules.js?ver=5.5.7' id='rabbit_js-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=3.7.2' id='woocommerce-js'></script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_227f88f0a3d1bf52fcb35e697697c784","fragment_name":"wc_fragments_227f88f0a3d1bf52fcb35e697697c784","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=3.7.2' id='wc-cart-fragments-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4' id='jquery-ui-core-js'></script>
<script type='text/javascript' id='qi-addons-for-elementor-script-js-extra'>
/* <![CDATA[ */
var qodefQiAddonsGlobal = {"vars":{"adminBarHeight":0,"iconArrowLeft":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 34.2 32.3\" xml:space=\"preserve\" style=\"stroke-width: 2;\"><line x1=\"0.5\" y1=\"16\" x2=\"33.5\" y2=\"16\"\/><line x1=\"0.3\" y1=\"16.5\" x2=\"16.2\" y2=\"0.7\"\/><line x1=\"0\" y1=\"15.4\" x2=\"16.2\" y2=\"31.6\"\/><\/svg>","iconArrowRight":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 34.2 32.3\" xml:space=\"preserve\" style=\"stroke-width: 2;\"><line x1=\"0\" y1=\"16\" x2=\"33\" y2=\"16\"\/><line x1=\"17.3\" y1=\"0.7\" x2=\"33.2\" y2=\"16.5\"\/><line x1=\"17.3\" y1=\"31.6\" x2=\"33.5\" y2=\"15.4\"\/><\/svg>","iconClose":"<svg  xmlns=\"http:\/\/www.w3.org\/2000\/svg\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" x=\"0px\" y=\"0px\" viewBox=\"0 0 9.1 9.1\" xml:space=\"preserve\"><g><path d=\"M8.5,0L9,0.6L5.1,4.5L9,8.5L8.5,9L4.5,5.1L0.6,9L0,8.5L4,4.5L0,0.6L0.6,0L4.5,4L8.5,0z\"\/><\/g><\/svg>"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/assets/js/main.min.js?ver=5.5.7' id='qi-addons-for-elementor-script-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.4' id='jquery-ui-widget-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-includes/js/jquery/ui/tabs.min.js?ver=1.11.4' id='jquery-ui-tabs-js'></script>
<script type='text/javascript' id='mediaelement-core-js-before'>
var mejsL10n = {"language":"en","strings":{"mejs.download-file":"Download File","mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen":"Fullscreen","mejs.play":"Play","mejs.pause":"Pause","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.live-broadcast":"Live Broadcast","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};
</script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=4.2.13-9993131' id='mediaelement-core-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-includes/js/mediaelement/mediaelement-migrate.min.js?ver=5.5.7' id='mediaelement-migrate-js'></script>
<script type='text/javascript' id='mediaelement-js-extra'>
/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive"};
/* ]]> */
</script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=5.5.7' id='wp-mediaelement-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/js/modules/plugins/jquery.appear.js?ver=5.5.7' id='appear-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/js/modules/plugins/modernizr.min.js?ver=5.5.7' id='modernizr-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-includes/js/hoverIntent.min.js?ver=1.8.1' id='hoverIntent-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/js/modules/plugins/owl.carousel.min.js?ver=5.5.7' id='owl-carousel-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/js/modules/plugins/jquery.waypoints.min.js?ver=5.5.7' id='waypoints-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/js/modules/plugins/fluidvids.min.js?ver=5.5.7' id='fluidvids-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/js/modules/plugins/perfect-scrollbar.jquery.min.js?ver=5.5.7' id='perfect-scrollbar-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/js/modules/plugins/ScrollToPlugin.min.js?ver=5.5.7' id='scroll-to-plugin-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/js/modules/plugins/parallax.min.js?ver=5.5.7' id='parallax-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/js/modules/plugins/jquery.waitforimages.js?ver=5.5.7' id='waitforimages-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/js/modules/plugins/jquery.prettyPhoto.js?ver=5.5.7' id='prettyphoto-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/js/modules/plugins/jquery.easing.1.3.js?ver=5.5.7' id='jquery-easing-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/plugins/js_composer/assets/lib/bower/isotope/dist/isotope.pkgd.min.js?ver=6.0.5' id='isotope-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/plugins/qi-addons-for-elementor/inc/masonry/assets/js/plugins/packery-mode.pkgd.min.js?ver=5.5.7' id='packery-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/js/modules/plugins/TweenLite.min.js?ver=5.5.7' id='tweenlite-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/js/modules/plugins/CSSPlugin.min.js?ver=5.5.7' id='cssplugin-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/plugins/woocommerce/assets/js/select2/select2.full.min.js?ver=4.0.3' id='select2-js'></script>
<script type='text/javascript' src='//maps.googleapis.com/maps/api/js?key=AIzaSyC6I9erACpEMySy_SBn2PhHNbyYtY5BG0g&#038;ver=5.5.7' id='chapterone-mikado-google-map-api-js'></script>
<script type='text/javascript' id='chapterone-mikado-modules-js-extra'>
/* <![CDATA[ */
var mkdfGlobalVars = {"vars":{"mkdf_add_for_admin_bar":0,"mkdf_element_eppear_amount":-100,"mkdf_ajax_url":"https:\/\/chapterone.qodeinteractive.com\/wp-admin\/admin-ajax.php","slider_nav_prev_arrow":"ion-ios-arrow-left","slider_nav_next_arrow":"ion-ios-arrow-right","pp_expand":"Expand the image","pp_next":"Next","pp_prev":"Previous","pp_close":"Close","mkdfStickyHeaderHeight":70,"mkdfStickyHeaderTransparencyHeight":70,"mkdfTopBarHeight":"50","mkdfLogoAreaHeight":0,"mkdfMenuAreaHeight":150,"mkdfMobileHeaderHeight":70}};
var mkdfPerPageVars = {"vars":{"mkdfMobileHeaderHeight":70,"mkdfStickyScrollAmount":1200,"mkdfHeaderTransparencyHeight":0,"mkdfHeaderVerticalWidth":0}};
/* ]]> */
</script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-content/themes/chapterone/assets/js/modules.min.js?ver=5.5.7' id='chapterone-mikado-modules-js'></script>
<script type='text/javascript' src='https://chapterone.qodeinteractive.com/wp-includes/js/wp-embed.min.js?ver=5.5.7' id='wp-embed-js'></script>
<section class="mkdf-side-menu">
	<a class="mkdf-close-side-menu mkdf-close-side-menu-icon-pack" href="#">
		<span aria-hidden="true" class="mkdf-icon-font-elegant icon_close "></span>	</a>
	<div id="media_image-3" class="widget mkdf-sidearea widget_media_image"><a href="https://chapterone.qodeinteractive.com"><img width="65" height="55" src="https://chapterone.qodeinteractive.com/wp-content/uploads/2019/08/logo-side.png" class="image wp-image-2063  attachment-full size-full" alt="f" loading="lazy" style="max-width: 100%; height: auto;" /></a></div><div class="widget mkdf-separator-widget"><div class="mkdf-separator-holder clearfix  mkdf-separator-center mkdf-separator-normal">
	<div class="mkdf-separator" style="border-style: solid;margin-bottom: 15px">
			</div>
</div>
</div>			
			<a class="mkdf-icon-widget-holder" 					href="https://www.google.com/maps/place/194+Amsterdam+Ave,+New+York,+NY+10023,+USA/@40.7766818,-73.9866015,17z/data=!3m1!4b1!4m5!3m4!1s0x89c25860389651d9:0xe674e38c4e7f6898!8m2!3d40.7766818!4d-73.9844128"
					target="_blank" >
				<span class="mkdf-icon-element icon_pin_alt" style="font-size: 15px"></span>				<span class="mkdf-icon-text ">1942 Amsterdam Ave NY</span>			</a>
						
			<a class="mkdf-icon-widget-holder" 					href="tel:2128623680"
					target="_self" >
				<span class="mkdf-icon-element icon_phone" style="font-size: 15px"></span>				<span class="mkdf-icon-text ">(212) 862-3680</span>			</a>
						
			<a class="mkdf-icon-widget-holder" 					href="mailto:chapter@example.com"
					target="_self" >
				<span class="mkdf-icon-element icon_mail_alt" style="font-size: 15px"></span>				<span class="mkdf-icon-text ">chapter@example.com</span>			</a>
			<div class="widget mkdf-separator-widget"><div class="mkdf-separator-holder clearfix  mkdf-separator-center mkdf-separator-normal">
	<div class="mkdf-separator" style="border-style: solid;margin-bottom: 30px">
			</div>
</div>
</div>			<div class="widget mkdf-contact-form-7-widget " >
								<div role="form" class="wpcf7" id="wpcf7-f14-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response" role="alert" aria-live="polite"></div>
<form action="/xmlrpc.php#wpcf7-f14-o1" method="post" class="wpcf7-form init" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="14" />
<input type="hidden" name="_wpcf7_version" value="5.2.2" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f14-o1" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
</div>
<div class="mkdf-grid-row mkdf-grid-normal-gutter">
<div class="mkdf-grid-col-12">
 <span class="wpcf7-form-control-wrap your-email"><input type="text" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Email" /></span>
</div>
<div class="mkdf-grid-col-12">
<button type="submit" class="wpcf7-form-control wpcf7-submit mkdf-btn-huge mkdf-btn mkdf-btn-medium mkdf-btn-solid"><span class="mkdf-btn-text">Subscribe</span></button>
</div>

</div><div class="wpcf7-response-output" role="alert" aria-hidden="true"></div></form></div>			</div>
			<div class="widget mkdf-social-icons-group-widget text-align-left">									<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover"  					   href="https://twitter.com/QodeInteractive" target="_blank">
						<span class="mkdf-social-icon-widget fab fa-twitter"></span>					</a>
													<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover"  					   href="https://www.instagram.com/qodeinteractive/" target="_blank">
						<span class="mkdf-social-icon-widget fab fa-instagram"></span>					</a>
													<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover"  					   href="https://www.facebook.com/QodeInteractive/" target="_blank">
						<span class="mkdf-social-icon-widget fab fa-facebook-f"></span>					</a>
													<a class="mkdf-social-icon-widget-holder mkdf-icon-has-hover"  					   href="https://dribbble.com/QodeInteractive" target="_blank">
						<span class="mkdf-social-icon-widget fab fa-dribbble"></span>					</a>
												</div><div id="custom_html-4" class="widget_text widget mkdf-sidearea widget_custom_html"><div class="textwidget custom-html-widget"><span style="color: #000; font-size: 10px; text-transform: uppercase; letter-spacing: 0.35em;line-height: 16px;margin-top: 15px;display: block;font-family:'Josefin Sans';">Free shipping <br> for orders over 50%</span>
</div></div></section></body>
</html>